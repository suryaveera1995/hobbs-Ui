import React from 'react';
import RaisedButton from 'material-ui/RaisedButton';
export default class MyAwesomeReactComponet extends React.Component{
  render(){
    return(
      <RaisedButton label="Default" />
    );
  }

}
