import React,{Component} from 'react';
import App from './App';
export default class AfterLogin extends Component{
  render(){
    return(
      <div>
        <App/>
    <h1 style={{margin:'100'}}>You have been granted permission to enter hobbs</h1>
    <div style={{margin: '100px'}}>please navigate</div>
    </div>
    )
  }
}
