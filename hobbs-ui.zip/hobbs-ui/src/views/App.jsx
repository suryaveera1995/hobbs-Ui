import React from 'react';
import darkBaseTheme from 'material-ui/styles/baseThemes/darkBaseTheme';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';
import IconButton from 'material-ui/IconButton';
import NotificationsIcon from 'material-ui/svg-icons/social/notifications';
import Badge from 'material-ui/Badge';
import Drawer from 'material-ui/Drawer';
import MenuItem from 'material-ui/MenuItem';
import {List, ListItem} from 'material-ui/List';
import DropDownMenu from 'material-ui/DropDownMenu';
import Divider from 'material-ui/Divider';
import Subheader from 'material-ui/Subheader';
import FileFolder from 'material-ui/svg-icons/file/folder';
import {blue500, yellow600} from 'material-ui/styles/colors';
import ActionInfo from 'material-ui/svg-icons/action/info';
import ActionAssignment from 'material-ui/svg-icons/action/assignment';
import EditorInsertChart from 'material-ui/svg-icons/editor/insert-chart';
import MapsPlace from 'material-ui/svg-icons/maps/place';
import IconMenu from 'material-ui/IconMenu';
import ArrowDropRight from 'material-ui/svg-icons/navigation-arrow-drop-right';
import NavigationClose from 'material-ui/svg-icons/navigation/close';

import MoreVertIcon from 'material-ui/svg-icons/navigation/more-vert';
import Avatar from 'material-ui/Avatar';
import FontIcon from 'material-ui/FontIcon';
import {
  blue300,
  indigo900,
  orange200,
  deepOrange300,
  pink400,
  purple500,
} from 'material-ui/styles/colors';

const style = {margin: 5};


export default class App extends React.Component{
  constructor(props) {
      super(props);
      this.state = {open: false};

    }

    handleToggle = () => this.setState({open: !this.state.open});
  render(){
    return(
      <MuiThemeProvider muiTheme={getMuiTheme(darkBaseTheme)}>

        <div>



          <AppBar title="Hobbes" style={{height:'65'}}

            iconElementLeft={<IconButton tooltip="options" onTouchTap={this.handleToggle}><MoreVertIcon /></IconButton>}>
                  <Drawer width={400} openPrimary={true} open={this.state.open}  >
                    <List>
      <Subheader

        >Browse
        <ListItem
        rightIcon={<MoreVertIcon  onTouchTap={this.handleToggle}></MoreVertIcon>}
        />


      </Subheader>

      <ListItem
        leftAvatar={<Avatar icon={<FileFolder />} />}
        rightIcon={<IconButton><ArrowDropRight/></IconButton>}

        maxHeight={272}
        primaryText="Dashboard"
      ></ListItem>
      <ListItem
        leftAvatar={<Avatar icon={<FileFolder />} />}
        rightIcon={<IconButton><ArrowDropRight/></IconButton>}
        primaryText="Assignments"
      ></ListItem>
  </List>
  <Divider inset={true} />
  <List>
    <Subheader inset={true}>Files</Subheader>
    <ListItem
      leftAvatar={<Avatar icon={<ActionAssignment />} backgroundColor={blue500} />}
      rightIcon={<IconButton tooltip="dashboard"><ActionInfo/></IconButton>}
      primaryText="dashboard"
    ></ListItem>
    <ListItem
      leftAvatar={<Avatar icon={<NotificationsIcon />} backgroundColor={yellow600} />}
      rightIcon={<IconButton tooltip="notifications"><ActionInfo/></IconButton>}
      primaryText="Notifications"
    ></ListItem>
  </List>

                    </Drawer>

                    <IconButton tooltip="Notifications" style={{margin:12}}>
                      <NotificationsIcon />
                    </IconButton>

                <Avatar style={{margin:12}}
                
                  color={blue300}
                  backgroundColor={indigo900}
                  size={40}
                />

                  </AppBar>
                  </div>
                </MuiThemeProvider>
              )
            }
            }
