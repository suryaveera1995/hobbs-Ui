import React,{Component} from 'react';
import {Link} from 'react-router';
export default class BeforeLogin extends React.Component{
  render(){
    return(
      <div>
        <h1 className="textwelcome">Welcome to Hobbes</h1><hr/>
        <img src="https://blog.juanwolf.fr/media/20150531_154323_b_1_q_0_p_1.jpg.png"  alt="gitlab"/>
          <button className="btn btn-default"><Link to="./AfterLogin">enter to hobes</Link></button>
      </div>
    )
  }
}
