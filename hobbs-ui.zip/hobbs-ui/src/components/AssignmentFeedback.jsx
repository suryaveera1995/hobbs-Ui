import React,{Component} from 'react';
import TextField from 'material-ui/TextField';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import App from '../views/App.jsx';
import MenuItem from 'material-ui/MenuItem';
import DropDownMenu from 'material-ui/DropDownMenu';

const styles = {
  customWidth: {
    width: 1000,
  },
};

export default class AssignmentFeedBack extends Component{
      constructor(props) {
          super(props);

          this.state = {value: 'Property Value'};
        }


        handleChange = (event) => {
          this.setState({
            value: event.target.value,
          });
        };
handleMyChange = (event, index, value) => this.setState({value});
handleMyFirstChange = (event, index, grade) => this.setState({grade});

        render() {
          return (
            <div>
              <App/>
              <MuiThemeProvider>
                <div className="container">
              <div className="jumbotron">
                <div className="well">
                  <h1>summary</h1>
                </div>
              </div>

<hr/>

              <div className="jumbotron">
                <div className="well">
                  <h1>Rubric</h1>
                </div>
              </div>
              <hr/>
              <div className="jumbotron">
                <DropDownMenu
          value={this.state.value}
          onChange={this.handleMyChange}
          style={styles.customWidth}
          autoWidth={false}
        >
          <MenuItem value={1} primaryText="good" />
          <MenuItem value={2} primaryText="satisfactory" />
          <MenuItem value={3} primaryText="very good" />
          <MenuItem value={4} primaryText="Excellent" />

        </DropDownMenu>
<hr/>
        <DropDownMenu
  value={this.state.grade}
  onChange={this.handleMyFirstChange}
  style={styles.customWidth}
  autoWidth={false}
>
  <MenuItem value={1} primaryText="good" />
  <MenuItem value={2} primaryText="satisfactory" />
  <MenuItem value={3} primaryText="very good" />
  <MenuItem value={3} primaryText="Excellent" />

</DropDownMenu>
              </div>
            </div>
          </MuiThemeProvider>
            </div>
          );
        }

  }
