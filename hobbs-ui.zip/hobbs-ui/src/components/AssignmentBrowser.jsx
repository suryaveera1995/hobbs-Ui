import React from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import App from '../views/App.jsx';
import {Tabs, Tab} from 'material-ui/Tabs';
import Slider from 'material-ui/Slider';
import {GridList, GridTile} from 'material-ui/GridList';
import Subheader from 'material-ui/Subheader';
import StarBorder from 'material-ui/svg-icons/toggle/star-border';
import IconButton from 'material-ui/IconButton';
import Avatar from 'material-ui/Avatar';
import FontIcon from 'material-ui/FontIcon';
import RaisedButton from 'material-ui/RaisedButton';
import {Card, CardActions, CardHeader, CardMedia, CardTitle, CardText} from 'material-ui/Card';
import FlatButton from 'material-ui/FlatButton';
import Toggle from 'material-ui/Toggle';
import NotificationsIcon from 'material-ui/svg-icons/social/notifications';



import {
  blue300,
  indigo900,
  orange200,
  deepOrange300,
  pink400,
  purple500,
} from 'material-ui/styles/colors';





const styles = {
  headline: {
    fontSize: 24,
    paddingTop: 100,
    marginBottom: 12,
    fontWeight: 400,
  },
  root: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
  },
  gridList: {
    width: 800,
    height: 800,
    overflowY: 'auto',
  },
};







export default class AssignmentBrowser extends React.Component{
  render(){
    return(
      <tag >
      <App/>

      <MuiThemeProvider>
<tagger style={{margin:10}}>
      <Tabs>
        <Tab label="Active">


                <GridList
      cellHeight={50}
      >
                <Subheader>Cards</Subheader>

                  <Card>


        <CardHeader
          title="gitlab"
          subtitle="title"
          avatar="https://gitlab.com/uploads/project/avatar/13083/logo-extra-whitespace.png"
          actAsExpander={true}
          showExpandableButton={true}
        />

        <CardMedia
          expandable={true}
          overlay={<CardTitle title="Overlay title" subtitle="Overlay subtitle" />}
        >
        <CardTitle title="Card title" subtitle="Card subtitle" expandable={true} />

          <img src="https://about.gitlab.com/images/press/logo/wm.svg" />
        </CardMedia>


        <CardText expandable={true}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          Donec mattis pretium massa. Aliquam erat volutpat. Nulla facilisi.
          Donec vulputate interdum sollicitudin. Nunc lacinia auctor quam sed pellentesque.
          Aliquam dui mauris, mattis quis lacus id, pellentesque lobortis odio.
        </CardText>
        <CardActions>

          <FlatButton label="Submit" />
          <FlatButton label="Resubmit"/>
<Avatar icon={<NotificationsIcon />} backgroundColor={indigo900} />
      </CardActions>
      </Card>




  </GridList>


        </Tab>
        <Tab label="Submitted">
          <div>
            <h2 style={styles.headline}>Tab Two</h2>
            <p>
              This is another example tab.
            </p>
          </div>
        </Tab>
        <Tab label="item three">
          <div>
            <h2 style={styles.headline}>Tab Three</h2>
            <p>
              This is a third example tab.
            </p>
          </div>
        </Tab>
      </Tabs>
    </tagger>

    </MuiThemeProvider>
  </tag >
    )
  }
}
