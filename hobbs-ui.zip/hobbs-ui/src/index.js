import React from 'react';
import ReactDOM from 'react-dom';
import App from './views/App';
import './App.css';
import AfterLogin from './views/AfterLogin';
import BeforeLogin from './views/BeforeLogin';
import AssignmentBrowser from './components/AssignmentBrowser';
import AssignmentFeedback from './components/AssignmentFeedback';
import Notifications from './components/Notifications';
import {IndexRoute, Router, Route, browserHistory,hashHistory} from 'react-router';


import injectTapEventPlugin from 'react-tap-event-plugin';
injectTapEventPlugin();

ReactDOM.render(

  <Router history={browserHistory}>
      <Route path="/" component={BeforeLogin}/>
        <IndexRoute component={BeforeLogin}/>
        <Route path="/AfterLogin" component={AfterLogin}/>
        <Route path="/AssignmentBrowser" component={AssignmentBrowser}/>
          {<Route path="/AssignmentFeedback" component={AssignmentFeedback}/>}
          <Route path="/Notifications" component={Notifications}/>

      </Router>,
      document.getElementById('root')
    );
